<?php
class Cmsmodel extends CI_model
{
	public function add_signup($name,$email,$password)
	{   
		$this->db->query('CREATE TABLE IF NOT EXISTS cms_signup(id int primary key AUTO_INCREMENT,name varchar(20),email varchar(30),password varchar(20))');
		$this->db->set('name',$name);
		$this->db->set('email',$email);
		$this->db->set('password',$password);
		$this->db->insert('cms_signup');
	}

	public function loginmodel($email,$password)
	{
		$query=$this->db->get_where('cms_signup',array('email'=>$email,'password'=>$password));
		return $query->result_array();
	}

	public function insertuser($name,$mobile,$email,$address,$img)
	{   
		$this->db->query('CREATE TABLE IF NOT EXISTS cms_userdata(id int primary key AUTO_INCREMENT,name varchar(20),email varchar(30),mobile bigint,address varchar(30),image varchar(30))');
		$this->db->set('name',$name);
		$this->db->set('email',$email);
		$this->db->set('mobile',$mobile);
		$this->db->set('address',$address);
		$this->db->set('image',$img);
		$this->db->insert('cms_userdata');
	}

	public function getdata()
	{
		$q=$this->db->get('cms_userdata');
		return $q->result_array();
	}

	public function de($id)
	{
		$this->db->where('id',$id);
		$this->db->delete('cms_userdata');

	}

	public function up($id)
	{
		$data=$this->db->get_where('cms_userdata',array('id'=>$id));
        return $data->result_array();
	}

	public function inup($arr,$id)
	{
		$this->db->where('id',$id);
		$this->db->update('cms_userdata',$arr);

	}

	public function change_password($email)
	{
		$query=$this->db->get_where('cms_signup',array('email'=>$email));
		return $query->result_array();
	}

	public function change_password_data($email,$password)
	{
		$this->db->where('email',$email);
		$this->db->update('cms_signup',array('password'=>$password));

	}
}
?>