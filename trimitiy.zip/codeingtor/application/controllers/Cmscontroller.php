<?php
class Cmscontroller extends CI_controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Cmsmodel');
	}

	public function login_page()
	{   
		$login['login']='login';
		$this->load->view('login.html',$login);
	}
    
    public function forgetpassword()
	{   
		$forgetpassword['forgetpassword']='forgetpassword';
		$this->load->view('login.html',$forgetpassword);
	}

	 public function forgetpassworddash()
	{   
		$forgetpassworddash['forgetpassworddash']='forgetpassworddash';
		$this->load->view('login.html',$forgetpassworddash);
	}

	public function signup()
	{
		$sign_up['sign_up']='sign_up';
		$this->load->view('login.html',$sign_up);
	}

	public function data()
	{
		{
      $this->form_validation->set_rules('email','email','trim|valid_email|is_unique[cms_signup.email]');
      if($this->form_validation->run()==FALSE)
      {
         redirect(site_url('Cmscontroller/signup'));
      }
      else
       { 
    	$name=$this->input->post('fullname');
		$email=$this->input->post('email');
		$password=$this->input->post('password');
	    $this->Cmsmodel->add_signup($name,$email,$password);
	    $this->session->set_flashdata('message','Registration Succesfully! Login Here');
	    redirect(site_url('Cmscontroller/login_page'));
    	
    	 }
    }}

    public function logindata()
    {
    	$email=$this->input->post('email');
		$password=$this->input->post('password');
		if($this->Cmsmodel->loginmodel($email,$password))
		{
			 redirect(site_url('Cmscontroller/dashboard'));
		}
		else
		{
			$this->session->set_flashdata('message','User name password does not match');
			redirect(site_url('Cmscontroller/login_page'));
		}

    }

    public function dashboard()
    {
    	$this->load->view('dashboard.html');

    }

    public function adduserdata()
    {
       $name=$this->input->post('fullname');
		$mobile=$this->input->post('mobile');
		$email=$this->input->post('email');
		$address=$this->input->post('address');
		$img=$this->img();
		$this->Cmsmodel->insertuser($name,$mobile,$email,$address,$img);
		redirect(site_url('Cmscontroller/dashboard'));
    }

    public function img()
	{
      $filename=basename($_FILES['img']['name']);
		move_uploaded_file($_FILES['img']['tmp_name'],'upimg/'.$filename);
		return $filename;
	}

	public function delete()
	{
		$id=$this->input->get('id');
		$this->Cmsmodel->de($id);
		redirect(site_url('Cmscontroller/dashboard'));

	}

	public function update()
	{
		$id=$this->input->get('id');
		$d['d']=$this->Cmsmodel->up($id);
		$this->load->view('login.html',$d);
	}

	public function updateuserdata()
	{
		$id=$this->input->post('id');
		$name=$this->input->post('fullname');
		$mobile=$this->input->post('mobile');
		$email=$this->input->post('email');
		$address=$this->input->post('address');
		$img=$this->upimg();
		$imgname=$this->input->post('imgname');
		if($img==Null)
		{
		 $arr=array(
         'name'=>$name,
         'mobile'=>$mobile,
         'email'=>$email,
         'address'=>$address,
         'image'=>$imgname    
		);
		$this->Cmsmodel->inup($arr,$id);
	    }
	    else
	    {
	    	 $arr=array(
         'name'=>$name,
         'mobile'=>$mobile,
         'email'=>$email,
         'address'=>$address,
         'image'=>$img    
		);
		$this->Cmsmodel->inup($arr,$id);
	    }
	    redirect(site_url('Cmscontroller/dashboard'));
        }

         public function upimg()
	{
      $filename=basename($_FILES['img']['name']);

		move_uploaded_file($_FILES['img']['tmp_name'],'upimg/'.$filename);
		return $filename;
	}

    public function forgetdata()
    {
    	$email=$this->input->post('email');
		$password=$this->input->post('password');
	    if($this->Cmsmodel->change_password($email))
	    {
	    	$this->Cmsmodel->change_password_data($email,$password);
	    
	    $this->session->set_flashdata('message','Password Change Succesfully! Login Here');
	    redirect(site_url('Cmscontroller/login_page'));
     	}
     	else
     	{
     		$this->session->set_flashdata('message','This Not Registerd Email ');
	    redirect(site_url('Cmscontroller/forgetpassword'));
     	}
    }
    

     public function forgetdatadash()
    {
    	$email=$this->input->post('email');
		$password=$this->input->post('password');
	    if($this->Cmsmodel->change_password($email))
	    {
	    	$this->Cmsmodel->change_password_data($email,$password);
	    
	    $this->session->set_flashdata('message','Password Change Succesfully!');
	    redirect(site_url('Cmscontroller/dashboard'));
     	}
     	else
     	{
     		$this->session->set_flashdata('message','This Not Registerd Email ');
	    redirect(site_url('Cmscontroller/dashboard'));
     	}
    }
}
?>