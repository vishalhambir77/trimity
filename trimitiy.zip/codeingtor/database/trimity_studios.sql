-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 03, 2020 at 12:20 PM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `nimap`
--

-- --------------------------------------------------------

--
-- Table structure for table `categorydata`
--

CREATE TABLE `categorydata` (
  `id` int(11) NOT NULL,
  `category` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categorydata`
--

INSERT INTO `categorydata` (`id`, `category`) VALUES
(1, 'electronic'),
(2, 'food'),
(3, 'jewllary'),
(4, 'chemical'),
(5, 'hardware'),
(6, 'software');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `category` varchar(10) NOT NULL,
  `product_name` varchar(10) NOT NULL,
  `product_quantity` int(11) NOT NULL,
  `product_price` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `category`, `product_name`, `product_quantity`, `product_price`) VALUES
(1, 'chemical', 'vineger', 1, '100'),
(2, 'electronic', 'fan', 12, '1200'),
(3, 'food', 'icecream', 1, '10'),
(4, 'jewllary', 'bangel', 2, '2000'),
(5, 'electronic', 'ac', 3, '15000'),
(6, 'electronic', 'T.V', 1, '20000'),
(7, 'food', 'burger', 5, '300'),
(8, 'food', 'coffee', 2, '100'),
(9, 'electronic', 'mobile', 1, '15000'),
(10, 'chemical', 'nicotin', 2, '2500'),
(11, 'electronic', 'lcd', 3, '1200'),
(12, 'food', 'pizza', 5, '500'),
(13, 'jewllary', 'rings', 1, '30000'),
(14, 'chemical', 'h2so4', 5, '15000'),
(15, 'food', 'chinese', 1, '100'),
(16, 'food', 'meet', 4, '300'),
(17, 'electronic', 'mixer', 1, '600'),
(18, 'chemical', 'salt', 1, '100'),
(19, 'electronic', 'iodine', 2, '300'),
(24, 'electronic', 'fan', 5, '1200'),
(26, 'electronic', 'ac', 2, '20000'),
(27, 'hardware', 'mouse', 3, '1500'),
(28, 'hardware', 'keyboard', 4, '4000'),
(29, 'food', 'burger', 3, '100'),
(30, 'electronic', 'cooler', 1, '10000'),
(31, 'software', 'msoffice', 1, '12000'),
(32, 'hardware', 'printer', 1, '20000'),
(33, 'hardware', 'speaker', 5, '2000'),
(34, 'hardware', 'pendrive', 1, '200'),
(35, 'electronic', 'motherboar', 2, '20000'),
(36, 'food', 'pizza', 1, '200'),
(37, 'software', 'os', 1, '10000');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categorydata`
--
ALTER TABLE `categorydata`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categorydata`
--
ALTER TABLE `categorydata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=38;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
